#!/usr/bin/env python3
"""IDQ Monitor - server del monitor (a spazi separati).

Ogni "spazio" ha il proprio token, i propri PC (agenti), le proprie scelte e il proprio PIN:
  - lo spazio PRINCIPALE (token in dati/monitor.token): il server vero e proprio, con tutte le funzioni;
  - gli spazi di PROVA (24 ore dal primo avvio, uno per dispositivo): con un PC dimostrativo e, se l'utente vuole, i suoi PC;
    alla scadenza lo spazio smette di rispondere (410) e viene cancellato.
Solo libreria standard di Python. Variabili d'ambiente: DATI_DIR, SERVIZI_SERVER, SERVIZI_ESSENZIALI, AGENTI_URL, PROVA_ORE, PROVE_MAX.
"""
import glob, hashlib, json, math, os, random, re, secrets, threading, time, urllib.parse, urllib.request, zipfile, io

DATI_DIR = os.environ.get("DATI_DIR", "/dati")
CARTELLA = os.path.dirname(os.path.abspath(__file__))
SERVIZI_SERVER = json.loads(os.environ.get("SERVIZI_SERVER", "{}") or "{}")          # {"Nome": porta}: servizi del server letti per porta (se manca l'agente)
SERVIZI_ESSENZIALI = set(json.loads(os.environ.get("SERVIZI_ESSENZIALI", "[]") or "[]"))   # per questi, porta chiusa = allarme
AGENTI_URL = os.environ.get("AGENTI_URL", "https://navi.assistente-joker.win/guida-server/agenti")   # da dove un server nuovo scarica gli agenti se non li ha
PROVA_ORE = float(os.environ.get("PROVA_ORE", "24"))
PROVE_MAX = int(os.environ.get("PROVE_MAX", "200"))         # prove attive contemporaneamente
PROVE_PER_IP = int(os.environ.get("PROVE_PER_IP", "3"))     # nuove prove per indirizzo in 24 ore
PC_MAX_PROVA = 6
PIATTAFORME = ("windows-x64", "macos-arm64", "macos-x64", "linux-x64", "linux-arm64")
BLOCCO = threading.Lock()


def _file(nome): return os.path.join(DATI_DIR, nome)


class Spazio:
    def __init__(self, token, tipo="principale", creato=None, scade=None):
        self.token = token; self.tipo = tipo; self.creato = creato or time.time(); self.scade = scade
        self.pc_inviati = {}          # nome -> (ora, dati): i PC con l'agente mandano qui i loro dati
        self.scelti = {}              # pc -> servizi che l'utente ha scelto di visualizzare (se manca: quelli della configurazione dell'agente)
        self.comandi = {}             # pc -> (ora, azione): riavvii confermati con il PIN, consegnati all'agente
        self.attivita_server = [0, None]
        self.pin_errori = [0, 0.0]

    @property
    def prova(self): return self.tipo == "prova"


def _token_principale():
    try: return open(_file("monitor.token")).read().strip()
    except OSError:
        t = secrets.token_urlsafe(18); os.makedirs(DATI_DIR, exist_ok=True); open(_file("monitor.token"), "w").write(t); return t


PRINCIPALE = None
PROVE = {}         # token -> Spazio
DISPOSITIVI = {}   # hash del dispositivo -> {"token":..., "scade":...}
NUOVE_PER_IP = {}  # ip -> [ore delle nuove prove]


def avvia():
    """Da chiamare una volta all'avvio: crea lo spazio principale, carica gli spazi di prova e le scelte salvate."""
    global PRINCIPALE
    PRINCIPALE = Spazio(_token_principale())
    try: PRINCIPALE.scelti.update(json.load(open(_file("servizi.json"))))
    except (OSError, ValueError): pass
    try:
        d = json.load(open(_file("prove.json")))
        for tok, v in d.get("spazi", {}).items(): PROVE[tok] = Spazio(tok, "prova", v["creato"], v["scade"])
        DISPOSITIVI.update(d.get("dispositivi", {}))
    except (OSError, ValueError, KeyError): pass
    pulisci_prove()


def _salva_prove():
    d = {"spazi": {t: {"creato": s.creato, "scade": s.scade} for t, s in PROVE.items()}, "dispositivi": DISPOSITIVI}
    tmp = _file("prove.json.tmp"); json.dump(d, open(tmp, "w")); os.replace(tmp, _file("prove.json"))


def pulisci_prove():
    """Toglie gli spazi di prova scaduti da piu' di 48 ore (i dispositivi restano segnati: la prova si fa una volta sola)."""
    with BLOCCO:
        for tok in [t for t, s in PROVE.items() if time.time() > s.scade + 48 * 3600]: PROVE.pop(tok, None)
        _salva_prove()


def spazio_da_token(k):
    """(spazio, codice): codice 0 = ok, 403 = token sconosciuto, 410 = prova scaduta."""
    if PRINCIPALE is None: avvia()
    if k == PRINCIPALE.token: return PRINCIPALE, 0
    sp = PROVE.get(k)
    if sp is None: return None, 403
    if time.time() > sp.scade: return None, 410
    return sp, 0


def nuova_prova(dispositivo, ip, base):
    """Crea (una sola volta per dispositivo) lo spazio di prova di 24 ore. Ritorna (codice, risposta)."""
    if not (isinstance(dispositivo, str) and re.fullmatch(r"[0-9a-f]{64}", dispositivo)): return 400, {"error": "dispositivo non valido"}
    with BLOCCO:
        v = DISPOSITIVI.get(dispositivo)
        if v:   # stesso dispositivo: stessa prova (una reinstallazione non azzera l'orario); scaduta = finita
            if time.time() > v["scade"]: return 403, {"error": "prova_gia_usata"}
            return 200, {"link": f"{base}/monitor?k={v['token']}", "scade": int(v["scade"])}
        attive = [s for s in PROVE.values() if time.time() <= s.scade]
        if len(attive) >= PROVE_MAX: return 503, {"error": "prove_esaurite"}
        ore = [t for t in NUOVE_PER_IP.get(ip, []) if time.time() - t < 86400]
        if len(ore) >= PROVE_PER_IP: return 429, {"error": "troppe_prove"}
        tok = secrets.token_urlsafe(18); ora = time.time()
        PROVE[tok] = Spazio(tok, "prova", ora, ora + PROVA_ORE * 3600)
        DISPOSITIVI[dispositivo] = {"token": tok, "scade": ora + PROVA_ORE * 3600}
        NUOVE_PER_IP[ip] = ore + [ora]
        _salva_prove()
        return 200, {"link": f"{base}/monitor?k={tok}", "scade": int(ora + PROVA_ORE * 3600)}


# ---------------------------------------------------------------- campionamento del PC su cui gira il server
def _cpu_tempi():
    """(totale, inattivo) per ogni riga cpu di /proc/stat: la prima e' il totale, poi un core per riga."""
    out = []
    for r in open("/proc/stat"):
        if not r.startswith("cpu"): break
        v = [int(x) for x in r.split()[1:]]; out.append((sum(v), v[3] + v[4]))
    return out

def _dischi_io():
    io = {}
    for r in open("/proc/diskstats"):
        f = r.split(); io[f[2]] = (int(f[5]) * 512, int(f[9]) * 512)
    return io

def _rete():
    rx = tx = 0
    for r in list(open("/proc/net/dev"))[2:]:
        n, v = r.split(":"); n = n.strip(); v = v.split()
        if n == "lo" or n.startswith(("docker", "br-", "veth")): continue
        rx += int(v[0]); tx += int(v[8])
    return rx, tx

def _partizioni():
    """Dischi e partizioni da /proc/partitions (solo elenco e dimensioni: nessuna partizione viene letta o montata)."""
    elenco = []
    for r in list(open("/proc/partitions"))[2:]:
        f = r.split()
        if len(f) == 4 and not f[3].startswith(("loop", "ram", "zram", "dm-")): elenco.append((f[3], int(f[2]) * 1024))
    dischi = []
    for n, t in elenco:
        madre = next((d for d in dischi if n.startswith(d["nome"]) and n != d["nome"]
                      and (n[len(d["nome"]):].lstrip("p").isdigit())), None)
        if madre: madre["parti"].append({"nome": n, "size": t})
        else: dischi.append({"nome": n, "size": t, "parti": []})
    return dischi

def _uso_conosciuto():
    """Spazio usato per le sole partizioni visibili dal servizio (Archivio IA via /dati, sistema via /): associate per dimensione."""
    uso = []
    for p in (DATI_DIR, "/"):
        try:
            st = os.statvfs(p); uso.append((st.f_blocks * st.f_frsize, (st.f_blocks - st.f_bavail) * st.f_frsize))
        except OSError: pass
    return uso

def _porta_aperta(porta):
    import socket
    try:
        with socket.create_connection(("127.0.0.1", porta), timeout=0.5): return True
    except OSError: return False



def monitor(sp):
    c1 = _cpu_tempi(); io1 = _dischi_io(); r1 = _rete(); t0 = time.time(); time.sleep(0.5)
    c2 = _cpu_tempi(); io2 = _dischi_io(); r2 = _rete(); dt_s = max(0.1, time.time() - t0)
    perc = [round(100 * (1 - (b[1] - a[1]) / max(1, b[0] - a[0])), 1) for a, b in zip(c1, c2)]
    cpu, core = perc[0], perc[1:]
    mem = {}
    for r in open("/proc/meminfo"):
        k, v = r.split(":"); mem[k] = int(v.split()[0]) * 1024
    ram_t = mem["MemTotal"]; ram_u = ram_t - mem["MemAvailable"]
    sw_t = mem.get("SwapTotal", 0); sw_u = sw_t - mem.get("SwapFree", 0)
    carico = [float(x) for x in open("/proc/loadavg").read().split()[:3]]
    up = int(float(open("/proc/uptime").read().split()[0]))
    nuclei = os.cpu_count() or 1
    temp = None; temps = []
    try:
        import glob
        for f in sorted(glob.glob("/sys/class/thermal/thermal_zone*/temp")):
            try:
                nome = open(os.path.dirname(f) + "/type").read().strip(); v = int(open(f).read()) / 1000
                temps.append({"nome": nome, "c": round(v, 1)})
            except (OSError, ValueError): pass
        if temps: temp = max(t["c"] for t in temps)
    except Exception: pass
    st = os.statvfs(DATI_DIR); dt = st.f_blocks * st.f_frsize; dl = st.f_bavail * st.f_frsize
    # dischi e partizioni, con spazio usato dove noto e traffico di lettura/scrittura
    dischi = _partizioni(); noti = _uso_conosciuto()
    for d in dischi:
        l = io2.get(d["nome"], (0, 0)); l0 = io1.get(d["nome"], (0, 0))
        d["lett"] = int((l[0] - l0[0]) / dt_s); d["scritt"] = int((l[1] - l0[1]) / dt_s)
        for p in d["parti"]:
            p["usato"] = None
            for i, (tot, usato) in enumerate(noti):
                if abs(tot - p["size"]) / p["size"] < 0.05: p["usato"] = usato; noti.pop(i); break
    sv = {n: _porta_aperta(p) for n, p in SERVIZI_SERVER.items()}
    allarmi = []
    if cpu >= 95: allarmi.append(f"Processore al {cpu}%")
    if carico[1] > nuclei * 1.5: allarmi.append(f"Carico alto ({carico[1]:.1f} su {nuclei} nuclei)")
    if ram_u / ram_t >= 0.92: allarmi.append(f"Memoria quasi piena ({100*ram_u/ram_t:.0f}%)")
    if sw_t and sw_u / sw_t >= 0.8: allarmi.append(f"Swap quasi piena ({100*sw_u/sw_t:.0f}%)")
    if (dt - dl) / dt >= 0.9: allarmi.append(f"Disco dei dati al {100*(dt-dl)/dt:.0f}%")
    if temp is not None and temp >= 85: allarmi.append(f"Temperatura alta ({temp} C)")
    for n in SERVIZI_SERVER:
        if not sv[n] and n in SERVIZI_ESSENZIALI: allarmi.append(f"Servizio spento: {n}")
    r = {"pc": "server", "allarmi": allarmi, "cpu": cpu, "core": core, "nuclei": nuclei, "carico": carico,
            "ram_tot": ram_t, "ram_usata": ram_u, "swap_tot": sw_t, "swap_usata": sw_u,
            "disco_tot": dt, "disco_usato": dt - dl, "dischi": dischi, "rete": {"rx": int((r2[0] - r1[0]) / dt_s), "tx": int((r2[1] - r1[1]) / dt_s)},
            "temperatura": temp, "temperature": temps, "uptime": up, "ora": int(time.time()), "servizi": sv,
            "attivita": None}
    ag = sp.attivita_server[1] if time.time() - sp.attivita_server[0] < 30 else None
    if ag:   # l'agente sul server distingue i servizi fermi da quelli arrestati in modo anomalo
        r["attivita"] = ag.get("attivita")
        if ag.get("servizi_rilevati"): r["servizi_rilevati"] = ag["servizi_rilevati"]
        if ag.get("servizi_stato"):
            r["servizi_stato"] = ag["servizi_stato"]; r["servizi"] = {n: v == "attivo" for n, v in ag["servizi_stato"].items()}
            r["allarmi"] = [a for a in r["allarmi"] if not a.startswith("Servizio spento")] + list(ag.get("allarmi", []))
    return r



# ---------------------------------------------------------------- PIN del riavvio (solo spazio principale)
PIN_FILE = lambda: _file("monitor.pin")
PIN_RIFIUTATO = lambda: _file("monitor.pin.rifiutato")


def stato_pin(sp):
    """'attivo' (PIN impostato), 'disattivo' (rifiutato o disattivato; sempre cosi' nelle prove) o 'da_chiedere' (le app lo chiedono al primo avvio)."""
    if sp.prova: return "disattivo"
    if os.path.exists(PIN_FILE()): return "attivo"
    return "disattivo" if os.path.exists(PIN_RIFIUTATO()) else "da_chiedere"


def _hash_pin(nuovo): return hashlib.sha256(("idq-monitor:" + nuovo).encode()).hexdigest()


def _scrivi_pin(nuovo):
    open(PIN_FILE(), "w").write(_hash_pin(nuovo)); os.chmod(PIN_FILE(), 0o600)
    if os.path.exists(PIN_RIFIUTATO()): os.remove(PIN_RIFIUTATO())


def _pin_ok(nuovo): return isinstance(nuovo, str) and nuovo.isdigit() and 4 <= len(nuovo) <= 8


def pin_valido(sp, pin):
    """True/False; None se bloccato (5 errori di fila = 5 minuti di attesa). Senza PIN attivo nessun riavvio da remoto."""
    if sp.pin_errori[0] >= 5 and time.time() - sp.pin_errori[1] < 300: return None
    if sp.prova or not os.path.exists(PIN_FILE()): return False
    ok = _hash_pin(str(pin)) == open(PIN_FILE()).read().strip()
    sp.pin_errori[0] = 0 if ok else sp.pin_errori[0] + 1; sp.pin_errori[1] = time.time()
    return ok


def gestisci_pin(sp, c):
    """imposta/rifiuta: solo se non e' attivo. cambia/disattiva/ripristina: richiedono il PIN attuale."""
    if sp.prova: return 403, {"error": "non disponibile nella prova"}
    azione = c.get("azione", "cambia"); st = stato_pin(sp)
    if azione == "imposta":
        if st == "attivo": return 409, {"error": "il PIN e' gia' impostato"}
        if not _pin_ok(c.get("nuovo")): return 400, {"error": "il nuovo PIN deve avere da 4 a 8 cifre"}
        _scrivi_pin(c["nuovo"]); return 200, {"ok": True, "stato": "attivo"}
    if azione == "rifiuta":
        if st == "attivo": return 409, {"error": "il PIN e' attivo"}
        open(PIN_RIFIUTATO(), "w").write("1"); return 200, {"ok": True, "stato": "disattivo"}
    if azione in ("cambia", "disattiva", "ripristina"):
        if st != "attivo": return 409, {"error": "il riavvio da remoto non e' attivo"}
        v = pin_valido(sp, str(c.get("attuale", "")))
        if v is None: return 429, {"error": "troppi tentativi, riprova tra 5 minuti"}
        if not v: return 403, {"error": "pin attuale errato"}
        if azione == "cambia":
            if not _pin_ok(str(c.get("nuovo", ""))): return 400, {"error": "il nuovo PIN deve avere da 4 a 8 cifre"}
            _scrivi_pin(str(c["nuovo"])); return 200, {"ok": True, "stato": "attivo"}
        os.remove(PIN_FILE())
        if azione == "disattiva": open(PIN_RIFIUTATO(), "w").write("1"); return 200, {"ok": True, "stato": "disattivo"}
        if os.path.exists(PIN_RIFIUTATO()): os.remove(PIN_RIFIUTATO())   # ripristina: come appena installato
        return 200, {"ok": True, "stato": "da_chiedere"}
    return 400, {"error": "azione sconosciuta"}


# ---------------------------------------------------------------- scelte, comandi, PC dimostrativo
def applica_scelti(sp, pc, d):
    """Mostra solo i servizi scelti dall'utente (gli allarmi riguardano solo quelli). 'servizi_disponibili' = tutti i servizi rilevati sul PC."""
    d = dict(d)
    disp = {**(d.get("servizi_rilevati") or {}), **(d.get("servizi_stato") or {})}
    if disp: d["servizi_disponibili"] = disp
    sc = sp.scelti.get(pc)
    d["servizi_scelti"] = sc
    d["pin_stato"] = stato_pin(sp)
    if sp.prova: d["prova_scade"] = int(sp.scade)
    if sc is not None and disp:
        mostrati = {n: disp[n] for n in sc if n in disp}
        d["servizi_stato"] = mostrati; d["servizi"] = {n: v == "attivo" for n, v in mostrati.items()}
        d["allarmi"] = [a for a in d.get("allarmi", []) if not a.startswith(("Servizio arrestato in modo anomalo", "Servizio spento"))] + \
                       [f"Servizio arrestato in modo anomalo: {n}" for n, v in mostrati.items() if v == "anomalo"]
    d.pop("servizi_rilevati", None)
    return d


def comando_per(sp, pc):
    c = sp.comandi.pop(pc, None)
    return c[1] if c and time.time() - c[0] < 120 else None


def demo_dati(sp):
    """PC dimostrativo delle prove: numeri verosimili che cambiano nel tempo."""
    t = time.time(); GB = 1073741824
    def onda(base, amp, per, fase=0.0): return base + amp * math.sin(t / per + fase)
    core = [round(max(1.0, min(97.0, onda(28 + 9 * i, 17, 6 + i, i))), 1) for i in range(4)]
    cpu = round(sum(core) / 4, 1)
    ram_u = int(onda(3.1, 0.4, 41) * GB); sw_u = int(onda(0.35, 0.05, 90) * GB)
    disco = 256 * GB; usato = int(onda(104, 0.2, 500) * GB)
    return {
        "pc": "server", "allarmi": [], "cpu": cpu, "core": core, "nuclei": 4,
        "carico": [round(onda(1.3, 0.5, 9), 2), round(onda(1.2, 0.3, 40), 2), round(onda(1.1, 0.2, 120), 2)],
        "ram_tot": 8 * GB, "ram_usata": ram_u, "swap_tot": 2 * GB, "swap_usata": sw_u,
        "disco_tot": disco, "disco_usato": usato,
        "dischi": [{"nome": "sda", "modello": "Disco dimostrativo", "size": disco, "lett": int(max(0, onda(2.0e6, 1.8e6, 5))), "scritt": int(max(0, onda(8e5, 7e5, 7))),
                    "parti": [{"nome": "sda1", "size": disco, "usato": usato, "punto": "/"}]}],
        "rete": {"rx": int(max(0, onda(4e5, 3.5e5, 4))), "tx": int(max(0, onda(9e4, 8e4, 6)))},
        "temperatura": round(onda(52, 6, 33), 1), "temperature": [{"nome": "processore", "c": round(onda(52, 6, 33), 1)}, {"nome": "disco", "c": round(onda(38, 2, 80), 1)}],
        "uptime": int(t - sp.creato) + 3 * 86400, "ora": int(t),
        "servizi": {"Sito web": True, "Database": True, "Backup notturno": False},
        "servizi_stato": {"Sito web": "attivo", "Database": "attivo", "Backup notturno": "fermo"},
        "servizi_rilevati": {"Sito web": "attivo", "Database": "attivo", "Backup notturno": "fermo", "Cache": "attivo", "Posta": "attivo", "Antivirus": "attivo"},
        "attivita": {"aggiornamenti": [], "da_installare": 12, "riavvio": False, "lavori": [],
                     "manutenzione": "Prova gratuita: questo è un PC dimostrativo. Collega i tuoi PC dal menu (Aggiungi dispositivo…).",
                     "docker": [], "riavvio_programmato": None, "riavvio_pacchetti": [], "aggiornamenti_pronti": []},
    }


def dati_pc(sp, pc):
    """Risposta di /monitor.json per un PC dello spazio."""
    if pc == "server":
        r = demo_dati(sp) if sp.prova else monitor(sp)
        return applica_scelti(sp, "server", r)
    ora_p, dati = sp.pc_inviati.get(pc, (0, None))
    voluto = bool(dati and dati.get("spegnimento"))   # spento o riavviato in modo normale: non e' un allarme
    if dati is None or voluto or time.time() - ora_p > 30:
        return {"spento": True, "voluto": voluto, "pc": pc, "ultimo": int(ora_p)}
    return applica_scelti(sp, pc, dati)


def elenco(sp):
    voluti = [n for n, (t, d) in sp.pc_inviati.items() if d.get("spegnimento")]
    spenti = [n for n, (t, d) in sp.pc_inviati.items() if time.time() - t > 30 and not d.get("spegnimento")]
    r = {"pc": ["server"] + sorted(sp.pc_inviati), "spenti": sorted(spenti), "spenti_voluti": sorted(voluti)}
    if sp.prova: r["prova_scade"] = int(sp.scade)
    return r


PAGINA_MONITOR = """<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>IDQ Monitor</title><meta name="theme-color" content="#0f1720"><link rel="manifest" href="/monitor/manifest.json?k=__K__">
<style>:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#0f1720;color:#e8eef5;font:14px system-ui,sans-serif;padding:10px}
h1{font-size:17px;margin:0 0 8px;display:flex;justify-content:space-between;align-items:center}small,.m{color:#8aa0b5}
#sc{display:flex;gap:6px;margin-bottom:8px}#sc button{flex:1;padding:8px;border:0;border-radius:10px;background:#18232f;color:#8aa0b5;font-size:14px}#sc button.a{background:#2b4a6a}
.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px}
.c{background:#18232f;border-radius:12px;padding:9px 11px}.t{font-size:11px;color:#8aa0b5;text-transform:uppercase;letter-spacing:.05em;display:flex;justify-content:space-between}
.v{font-size:22px;font-weight:700}.b{height:7px;background:#0f1720;border-radius:4px;overflow:hidden;margin:3px 0}
.b i{display:block;height:100%;background:#3ddc84;transition:width .5s}.w i{background:#ffb020}.x i{background:#ff5252}
.core{display:grid;grid-template-columns:repeat(auto-fill,minmax(70px,1fr));gap:5px;margin-top:5px}.core div{font-size:11px;color:#8aa0b5}
.d{margin-top:6px;border-top:1px solid #223;padding-top:5px}.d .r{display:flex;justify-content:space-between;font-size:12px}.p{padding-left:10px;margin-top:3px}
.al{background:#5c1a1a;border:1px solid #ff5252;border-radius:10px;padding:7px 10px;margin-bottom:6px;font-weight:600}.ok{color:#3ddc84}.no{color:#ff5252}
</style></head><body><h1>IDQ Monitor <small id="ora"></small></h1><div id="sc"></div><div id="al"></div><div class="g" id="g"></div>
<div class="m" style="margin:14px 2px;font-size:13px"><a href="/monitor/guida?k=__K__" style="color:#6fa8dc">Guida completa</a> · <a href="#" style="color:#6fa8dc" onclick="menuPin();return false">PIN del riavvio</a> · <a href="#" style="color:#6fa8dc" onclick="aggiungi();return false">Aggiungi dispositivo</a> · <a href="#" style="color:#6fa8dc" onclick="sceltaServizi();return false">Servizi da visualizzare</a></div>
<script>const K="__K__";let PC="server";const G=n=>(n/1073741824).toFixed(1),M=n=>n>=1048576?(n/1048576).toFixed(1)+" MB/s":(n/1024).toFixed(0)+" KB/s";
const cl=p=>p>=90?"x":p>=75?"w":"",pr=(a,b)=>b?100*a/b:0;
const bar=p=>`<div class="b ${cl(p)}"><i class="${cl(p)}" style="width:${Math.min(100,p)}%"></i></div>`;
function card(t,v,p,x){return `<div class="c"><div class="t"><span>${t}</span><span>${x||""}</span></div><div class="v">${v}</div>${bar(p)}</div>`}
async function elenco(){try{const e=await (await fetch("/monitor/elenco?k="+K)).json();document.getElementById("sc").innerHTML=e.pc.map(n=>{const on=n=="server"||(!(e.spenti||[]).includes(n)&&!(e.spenti_voluti||[]).includes(n)),c=on?"#3ddc84":"#ff5252";return `<button class="${n==PC?"a":""}" style="color:${c}" onclick="PC='${n}';elenco();agg()"><b style="font-size:15px">${n=="server"?"Server":n}</b><br><small style="color:#fff">${on?"attivo":"spento"}</small></button>`}).join("")}catch(e){}}
let ULTIMO=null;
function sceltaServizi(){const disp=(ULTIMO&&ULTIMO.servizi_disponibili)||{};const nomi=Object.keys(disp).sort((a,b)=>a.localeCompare(b));if(!nomi.length){alert("Nessun servizio rilevato su questo PC");return}
const mostrati=new Set(Object.keys(ULTIMO.servizi_stato||{}));const d=document.createElement("div");d.style.cssText="position:fixed;inset:0;background:#000a;display:flex;align-items:center;justify-content:center;z-index:9";
d.innerHTML=`<div style="background:#18232f;border-radius:14px;padding:16px;max-width:420px;width:92%;max-height:86vh;display:flex;flex-direction:column"><b>Servizi da visualizzare (${PC=="server"?"Server":PC})</b><div class="m" style="margin:6px 0">Scegli quali dei servizi rilevati vuoi vedere. Gli avvisi riguardano solo quelli scelti.</div><div id="el" style="overflow:auto;flex:1">${nomi.map((n,i)=>`<label style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #223"><span><input type="checkbox" data-n="${i}" ${mostrati.has(n)?"checked":""}> ${n}</span><span class="${disp[n]=="attivo"?"ok":disp[n]=="fermo"?"m":"no"}">${disp[n]=="attivo"?"attivo":disp[n]=="fermo"?"fermo":"arrestato"}</span></label>`).join("")}</div>
<div style="display:flex;gap:8px;margin-top:10px"><button id="pr" style="flex:1;padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff">Predefiniti</button><button id="an" style="flex:1;padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff">Annulla</button><button id="sa" style="flex:1;padding:10px;border:0;border-radius:8px;background:#2b4a6a;color:#fff">Salva</button></div></div>`;
document.body.appendChild(d);document.getElementById("an").onclick=()=>d.remove();
const invia=async sc=>{try{const r=await fetch("/monitor/servizi?k="+K,{method:"POST",body:JSON.stringify({pc:PC,scelti:sc})});if(r.ok){d.remove();agg()}else alert("Salvataggio non riuscito")}catch(e){alert("Salvataggio non riuscito")}};
document.getElementById("sa").onclick=()=>invia([...d.querySelectorAll("input:checked")].map(x=>nomi[+x.dataset.n]));document.getElementById("pr").onclick=()=>invia(null)}
function aggiungi(){const n=prompt("Nome del nuovo dispositivo (lettere, numeri, - e _):");if(!n)return;const u=`${location.origin}/monitor/installa?k=${K}&nome=${encodeURIComponent(n)}`;
const c1=`curl -fsSL -A Mozilla "${u}" | bash`,c2=`irm "${u}&sistema=windows" | iex`;
const d=document.createElement("div");d.style.cssText="position:fixed;inset:0;background:#000a;display:flex;align-items:center;justify-content:center;z-index:9;overflow:auto";
d.innerHTML=`<div style="background:#18232f;border-radius:14px;padding:16px;max-width:560px;width:92%"><b>Aggiungi "${n}"</b><div class="m" style="margin:8px 0">Sul nuovo PC apri il terminale (Linux, Raspberry, Mac) o PowerShell (Windows), incolla il comando giusto e premi invio. Dopo pochi secondi il dispositivo compare qui.</div>
<div class="m">Linux, Raspberry, Mac (Terminale):</div><textarea id="c1" readonly style="width:100%;height:70px;padding:8px;border-radius:8px;border:0;background:#0f1720;color:#e8eef5;font:13px monospace"></textarea><button id="b1" style="padding:8px;border:0;border-radius:8px;background:#2b4a6a;color:#fff;margin:4px 0 10px">Copia</button>
<div class="m">Windows (PowerShell):</div><textarea id="c2" readonly style="width:100%;height:70px;padding:8px;border-radius:8px;border:0;background:#0f1720;color:#e8eef5;font:13px monospace"></textarea><button id="b2" style="padding:8px;border:0;border-radius:8px;background:#2b4a6a;color:#fff;margin:4px 0">Copia</button>
<div><button id="ch" style="width:100%;padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff;margin-top:8px">Chiudi</button></div></div>`;
document.body.appendChild(d);document.getElementById("c1").value=c1;document.getElementById("c2").value=c2;document.getElementById("ch").onclick=()=>d.remove();
for(const [b,i,c] of [["b1","c1",c1],["b2","c2",c2]])document.getElementById(b).onclick=()=>{document.getElementById(i).select();try{navigator.clipboard.writeText(c)}catch(e){document.execCommand("copy")}document.getElementById(b).textContent="Copiato"}}
function mod(h,fn){const d=document.createElement("div");d.style.cssText="position:fixed;inset:0;background:#000a;display:flex;align-items:center;justify-content:center;z-index:9";d.innerHTML=`<div style="background:#18232f;border-radius:14px;padding:16px;max-width:380px;width:92%">${h}</div>`;document.body.appendChild(d);fn(d);return d}
const inp=(id,p)=>`<input id="${id}" type="password" inputmode="numeric" placeholder="${p}" style="width:100%;padding:10px;border-radius:8px;border:0;font-size:17px;margin:4px 0">`;
const bt=(id,t,c)=>`<button id="${id}" style="flex:1;padding:10px;border:0;border-radius:8px;background:${c||"#0f1720"};color:#fff">${t}</button>`;
const ESITO={200:null,400:"Il PIN deve avere da 4 a 8 cifre",403:"PIN attuale errato",409:"Operazione non possibile in questo stato",429:"Troppi tentativi: riprova tra 5 minuti"};
async function pinAz(azione,attuale,nuovo){try{const r=await fetch("/monitor/pin?k="+K,{method:"POST",body:JSON.stringify({azione,attuale:attuale||"",nuovo:nuovo||""})});return r.status}catch(e){return 0}}
function attivaPin(){mod(`<b>Imposta il PIN del riavvio</b>${inp("p1","Nuovo PIN (4-8 cifre)")}${inp("p2","Ripeti il PIN")}<div id="es" class="no" style="margin:6px 0"></div><div style="display:flex;gap:8px">${bt("an","Annulla")}${bt("ok","Attiva","#2b4a6a")}</div>`,d=>{
d.querySelector("#an").onclick=()=>d.remove();d.querySelector("#ok").onclick=async()=>{const a=d.querySelector("#p1").value;if(a!==d.querySelector("#p2").value){d.querySelector("#es").textContent="I due PIN non coincidono";return}
const c=await pinAz("imposta","",a);if(c==200){d.remove();alert("Riavvio da remoto attivato");agg()}else d.querySelector("#es").textContent=ESITO[c]||"Richiesta non riuscita"}})}
function primoAvvioPin(){mod(`<b>Riavvio da remoto</b><div class="m" style="margin:8px 0">Vuoi poter riavviare i tuoi PC dall'app quando ci sono aggiornamenti da applicare?<br><br>Ogni riavvio sarà protetto da un PIN che scegli ora. Puoi modificarlo, ripristinarlo o disattivarlo in qualsiasi momento dal menu.</div><div style="display:flex;gap:8px">${bt("no","No, grazie")}${bt("si","Sì, imposta il PIN","#2b4a6a")}</div>`,d=>{
d.querySelector("#no").onclick=async()=>{await pinAz("rifiuta");d.remove()};d.querySelector("#si").onclick=()=>{d.remove();attivaPin()}})}
function azioneRischiosa(titolo,avviso,azione,fatto){mod(`<b>${titolo}</b><div class="m" style="margin:8px 0">⚠ Lo fai a tuo rischio e pericolo.<br><br>${avviso}<br><br>Per confermare inserisci il PIN attuale.</div>${inp("pa","PIN attuale")}<div id="es" class="no" style="margin:6px 0"></div><div style="display:flex;gap:8px">${bt("an","Annulla")}${bt("ok","Conferma","#2b4a6a")}</div>`,d=>{
d.querySelector("#an").onclick=()=>d.remove();d.querySelector("#ok").onclick=async()=>{const c=await pinAz(azione,d.querySelector("#pa").value);if(c==200){d.remove();alert(fatto);if(azione=="ripristina")PINCHIESTO=false;agg()}else d.querySelector("#es").textContent=ESITO[c]||"Richiesta non riuscita"}})}
function modificaPin(){mod(`<b>Modifica PIN</b>${inp("pa","PIN attuale")}${inp("p1","Nuovo PIN (4-8 cifre)")}${inp("p2","Ripeti il nuovo PIN")}<div id="es" class="no" style="margin:6px 0"></div><div style="display:flex;gap:8px">${bt("an","Annulla")}${bt("ok","Conferma","#2b4a6a")}</div>`,d=>{
d.querySelector("#an").onclick=()=>d.remove();d.querySelector("#ok").onclick=async()=>{const n=d.querySelector("#p1").value;if(n!==d.querySelector("#p2").value){d.querySelector("#es").textContent="I due PIN non coincidono";return}
const c=await pinAz("cambia",d.querySelector("#pa").value,n);if(c==200){d.remove();alert("PIN modificato")}else d.querySelector("#es").textContent=ESITO[c]||"Richiesta non riuscita"}})}
function menuPin(){if(!ULTIMO||ULTIMO.pin_stato!="attivo"){attivaPin();return}
mod(`<b>PIN del riavvio</b><div style="display:flex;flex-direction:column;gap:8px;margin-top:10px"><button id="b1" style="padding:10px;border:0;border-radius:8px;background:#2b4a6a;color:#fff">Modifica PIN</button><button id="b2" style="padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff">Ripristina PIN…</button><button id="b3" style="padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff">Disattiva il riavvio da remoto…</button><button id="b4" style="padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff">Chiudi</button></div>`,d=>{
d.querySelector("#b4").onclick=()=>d.remove();d.querySelector("#b1").onclick=()=>{d.remove();modificaPin()};
d.querySelector("#b2").onclick=()=>{d.remove();azioneRischiosa("Ripristina PIN","Il PIN verrà cancellato e l'app ti chiederà di sceglierne uno nuovo. Fino ad allora il riavvio da remoto non è disponibile.","ripristina","PIN ripristinato: scegline uno nuovo")};
d.querySelector("#b3").onclick=()=>{d.remove();azioneRischiosa("Disattiva il riavvio da remoto","Non potrai più riavviare i PC dall'app. Senza PIN, i riavvii avverranno solo di notte (02:30).","disattiva","Riavvio da remoto disattivato")}})}
let PINCHIESTO=false;
function riavvia(pk,lav){if(!ULTIMO||ULTIMO.pin_stato!='attivo'){attivaPin();return}const nome=PC=="server"?"il server":PC;const d=document.createElement("div");d.style.cssText="position:fixed;inset:0;background:#000a;display:flex;align-items:center;justify-content:center;z-index:9";
d.innerHTML=`<div style="background:#18232f;border-radius:14px;padding:16px;max-width:340px;width:90%"><b>Riavviare ${nome} adesso?</b><div class="m" style="margin:8px 0">Aggiornamenti da applicare: ${pk}<br>Se non lo riavvii ora, si riavvia da solo alle 02:30.${lav?"<br><br>⚠ Lavori in corso che verranno interrotti: "+lav:""}</div><input id="pin" type="password" inputmode="numeric" placeholder="PIN" style="width:100%;padding:10px;border-radius:8px;border:0;font-size:18px;margin-bottom:10px"><div id="es" class="no" style="margin-bottom:8px"></div><div style="display:flex;gap:8px"><button id="an" style="flex:1;padding:10px;border:0;border-radius:8px;background:#0f1720;color:#fff">Annulla</button><button id="co" style="flex:1;padding:10px;border:0;border-radius:8px;background:#2b4a6a;color:#fff">Conferma</button></div></div>`;
document.body.appendChild(d);document.getElementById("an").onclick=()=>d.remove();
document.getElementById("co").onclick=async()=>{try{const r=await fetch("/monitor/comando?k="+K,{method:"POST",body:JSON.stringify({pc:PC,azione:"riavvia",pin:document.getElementById("pin").value})});
if(r.ok){d.remove();alert("Riavvio richiesto: parte entro pochi secondi")}else document.getElementById("es").textContent=r.status==403?"PIN errato":r.status==429?"Troppi tentativi, riprova tra 5 minuti":"Richiesta non riuscita"}catch(e){document.getElementById("es").textContent="Richiesta non riuscita"}}}
async function agg(){try{const rs=await fetch("/monitor.json?k="+K+"&pc="+PC,{cache:"no-store"});if(rs.status==410){document.getElementById("al").innerHTML='<div class="al">La prova di 24 ore è terminata. Per continuare collega il tuo server: guida su /guida-server</div>';document.getElementById("g").innerHTML="";return}const d=await rs.json();ULTIMO=d;if(d.pin_stato=='da_chiedere'&&!PINCHIESTO){PINCHIESTO=true;primoAvvioPin()}
if(d.spento){document.getElementById("al").innerHTML=d.voluto?`<div class="c m">${PC} e' spento (spegnimento normale)</div>`:`<div class="al">⚠ ${PC} non invia dati: spento o non raggiungibile</div>`;document.getElementById("g").innerHTML="";return}
const up=d.uptime,gg=Math.floor(up/86400),hh=Math.floor(up%86400/3600),mm=Math.floor(up%3600/60);
document.getElementById("al").innerHTML=(d.prova_scade?`<div class="c m">Prova gratuita: scade tra ${Math.max(0,Math.floor((d.prova_scade-Date.now()/1000)/3600))} h ${Math.max(0,Math.floor((d.prova_scade-Date.now()/1000)%3600/60))} min. Poi serve il tuo server (guida: /guida-server).</div>`:"")+d.allarmi.map(a=>`<div class="al">⚠ ${a}</div>`).join("");
const cores=d.core.map((c,i)=>`<div>core ${i}<div class="b ${cl(c)}"><i class="${cl(c)}" style="width:${c}%"></i></div>${c.toFixed(0)}%</div>`).join("");
const dischi=d.dischi.map(k=>`<div class="d"><div class="r"><b>${k.nome}${k.modello?" · "+k.modello:""}</b><span class="m">${G(k.size)} GB · ↓${M(k.lett)} ↑${M(k.scritt)}</span></div>`+k.parti.map(p=>`<div class="p"><div class="r"><span>${p.nome}${p.punto?" <span class=m>"+p.punto+"</span>":""}</span><span class="m">${p.usato==null?"":G(p.usato)+" / "}${G(p.size)} GB</span></div>${p.usato==null?"":bar(pr(p.usato,p.size))}</div>`).join("")+`</div>`).join("");
const svL=Object.entries(d.servizi_stato||Object.fromEntries(Object.entries(d.servizi||{}).map(([n,o])=>[n,o?"attivo":"fermo"])));const sv0=svL.map(([n,st])=>`<div class="r" style="display:flex;justify-content:space-between"><span>${n}</span><b class="${st=="attivo"?"ok":st=="fermo"?"m":"no"}">${st=="attivo"?"attivo":st=="fermo"?"fermo":"arrestato!"}</b></div>`).join("");const sv=svL.length>6?`<div style="display:grid;grid-template-columns:1fr 1fr;gap:0 14px">${sv0}</div>`:sv0;
const A=d.attivita,av=[];if(A){A.aggiornamenti.forEach(x=>av.push("🔄 Aggiornamento in corso: "+x));A.lavori.forEach(x=>av.push("⚙ In corso: "+x));if(A.manutenzione)av.push("🔧 Manutenzione: "+A.manutenzione);if(A.riavvio)av.push("↻ Riavvio necessario");if(A.riavvio_programmato)av.push("🕑 Riavvio programmato alle "+new Date(A.riavvio_programmato*1000).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}));A.docker.forEach(x=>av.push("🐳 "+x))}
const att=A?`<div class="c"><div class="t"><span>Attività e manutenzione</span><span>${A.da_installare==null?"":A.da_installare+" aggiornamenti da installare"}</span></div>${av.length?av.map(x=>`<div style="margin-top:4px">${x}</div>`).join(""):'<div class="m" style="margin-top:4px">Nessun aggiornamento o manutenzione in corso</div>'}${A.riavvio?`<button style="margin-top:8px;padding:8px 12px;border:0;border-radius:8px;background:#2b4a6a;color:#fff" onclick="riavvia(${JSON.stringify((A.riavvio_pacchetti||[]).join(", "))},${JSON.stringify((A.lavori||[]).join(", "))})">Riavvia ora…</button>`:""}</div>`:"";
document.getElementById("g").innerHTML=att+
`<div class="c"><div class="t"><span>Processore</span><span>${d.nuclei} core</span></div><div class="v">${d.cpu.toFixed(0)}%</div>${bar(d.cpu)}<div class="core">${cores}</div></div>`+
card("Carico",d.carico[0].toFixed(2),pr(d.carico[0],d.nuclei),"5m "+d.carico[1].toFixed(2)+" · 15m "+d.carico[2].toFixed(2))+
card("Memoria",G(d.ram_usata)+" GB",pr(d.ram_usata,d.ram_tot),"su "+G(d.ram_tot)+" GB")+
card("Swap",G(d.swap_usata)+" GB",pr(d.swap_usata,d.swap_tot),"su "+G(d.swap_tot)+" GB")+
`<div class="c"><div class="t"><span>Dischi e partizioni</span></div>${dischi}</div>`+
`<div class="c"><div class="t"><span>Rete</span><span>acceso da ${gg}g ${hh}h ${mm}m</span></div><div class="v" style="font-size:16px">↓ ${M(d.rete.rx)} · ↑ ${M(d.rete.tx)}</div></div>`+
`<div class="c"><div class="t"><span>Temperature</span><span>${d.temperatura==null?"":"massima "+d.temperatura.toFixed(0)+" °C"}</span></div>${(d.temperature||[]).map(t=>`<div class="r" style="display:flex;justify-content:space-between;margin-top:4px"><span>${t.nome}</span><b class="${t.c>=85?"no":""}">${t.c.toFixed(0)} °C</b></div>${bar(t.c)}`).join("")||'<div class="m">Nessun sensore rilevato</div>'}</div>`+
(sv?`<div class="c"><div class="t"><span>Servizi</span></div>${sv}</div>`:"");
document.getElementById("ora").textContent=new Date().toLocaleTimeString()}catch(e){document.getElementById("ora").textContent="server non raggiungibile"}}
elenco();agg();setInterval(agg,3000);setInterval(elenco,5000);</script></body></html>"""


SCRIPT_INSTALLA = r"""#!/bin/bash
# IDQ Monitor - installazione dell'agente su questo PC (Linux, Raspberry o Mac). Generata dal server.
set -e
NOME="__NOME__"; BASE="__BASE__"; K="__K__"
UA="Mozilla IDQ-Monitor-installer"
SISTEMA="$(uname -s)"
mkdir -p "$HOME/idq-monitor" "$HOME/.config"
cat > "$HOME/.config/idq-monitor-agente.json" <<EOT
{"link": "$BASE/monitor?k=$K", "nome": "$NOME"}
EOT
chmod 600 "$HOME/.config/idq-monitor-agente.json"

if [ "$SISTEMA" = "Darwin" ]; then
  # ---- macOS: eseguibile + avvio automatico con launchd
  case "$(uname -m)" in arm64) PIATTAFORMA="macos-arm64";; *) PIATTAFORMA="macos-x64";; esac
  curl -fsSL -A "$UA" "$BASE/monitor/agente/$PIATTAFORMA?k=$K" -o "$HOME/idq-monitor/idq-monitor-agente"
  chmod +x "$HOME/idq-monitor/idq-monitor-agente"
  PLIST="$HOME/Library/LaunchAgents/it.idq.monitor-agente.plist"
  mkdir -p "$HOME/Library/LaunchAgents"
  cat > "$PLIST" <<EOT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>it.idq.monitor-agente</string>
<key>ProgramArguments</key><array><string>$HOME/idq-monitor/idq-monitor-agente</string></array>
<key>RunAtLoad</key><true/>
<key>KeepAlive</key><true/>
<key>StandardErrorPath</key><string>$HOME/idq-monitor/agente.log</string>
</dict></plist>
EOT
  launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || true
  launchctl bootstrap "gui/$(id -u)" "$PLIST"
  echo "Fatto (macOS): questo Mac compare in IDQ Monitor come '$NOME' entro pochi secondi."
  echo "Per rimuoverlo: launchctl bootout gui/$(id -u) $PLIST && rm -rf ~/idq-monitor $PLIST"
else
  # ---- Linux e Raspberry: script Python + servizio systemd utente
  command -v python3 >/dev/null || { echo "Serve python3: installalo con 'sudo apt install python3' e rilancia il comando."; exit 1; }
  mkdir -p "$HOME/.config/systemd/user"
  curl -fsSL -A "$UA" "$BASE/monitor/agente.py?k=$K" -o "$HOME/idq-monitor/agente_pc.py"
  cat > "$HOME/.config/systemd/user/idq-monitor-agente.service" <<'EOT'
[Unit]
Description=IDQ Monitor - agente di questo PC
After=network-online.target

[Service]
ExecStart=/usr/bin/python3 -u %h/idq-monitor/agente_pc.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOT
  systemctl --user daemon-reload
  systemctl --user enable --now idq-monitor-agente
  loginctl enable-linger "$USER" 2>/dev/null || true
  echo
  echo "Fatto: questo PC compare in IDQ Monitor come '$NOME' (entro pochi secondi)."
  echo "Per scegliere i servizi da controllare modifica ~/.config/idq-monitor-agente.json (vedi la guida) e riavvia con: systemctl --user restart idq-monitor-agente"
fi
"""

SCRIPT_INSTALLA_WINDOWS = r"""# IDQ Monitor - installazione dell'agente su questo PC Windows (PowerShell). Generata dal server.
$ErrorActionPreference = "Stop"
$Nome = "__NOME__"; $Base = "__BASE__"; $K = "__K__"
$cartella = Join-Path $env:LOCALAPPDATA "IDQMonitor"
New-Item -ItemType Directory -Force -Path $cartella | Out-Null
$exe = Join-Path $cartella "IDQ-Monitor-Agente.exe"
Get-Process -Name "IDQ-Monitor-Agente" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 1
Invoke-WebRequest -UseBasicParsing -UserAgent "Mozilla IDQ-Monitor-installer" -Uri "$Base/monitor/agente/windows-x64?k=$K" -OutFile $exe
$config = @{ link = "$Base/monitor?k=$K"; nome = $Nome } | ConvertTo-Json
[System.IO.File]::WriteAllText((Join-Path $env:APPDATA "idq-monitor-agente.json"), $config, (New-Object System.Text.UTF8Encoding($false)))
# avvio automatico: all'accesso e ogni 5 minuti (se non e' gia' in esecuzione), senza finestre
$comando = "if (-not (Get-Process -Name 'IDQ-Monitor-Agente' -ErrorAction SilentlyContinue)) { Start-Process -WindowStyle Hidden -FilePath '$exe' }"
$azione = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -Command `"$comando`""
$trigger1 = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$trigger2 = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
$impostazioni = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName "IDQMonitorAgente" -Action $azione -Trigger @($trigger1, $trigger2) -Settings $impostazioni -Force | Out-Null
Start-Process -WindowStyle Hidden -FilePath $exe
Write-Host ""
Write-Host "Fatto: questo PC compare in IDQ Monitor come '$Nome' entro pochi secondi."
Write-Host "Per rimuoverlo: Unregister-ScheduledTask -TaskName IDQMonitorAgente -Confirm:`$false; Stop-Process -Name IDQ-Monitor-Agente; Remove-Item -Recurse $cartella"
"""

# ---------------------------------------------------------------- server autonomo (per chi ha il proprio server)
RUNNER = '''#!/usr/bin/env python3
"""IDQ Monitor - avvio del server del monitor da solo (nessuna dipendenza oltre a Python 3).  Uso: python3 idq_monitor_server.py"""
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import monitor_server as MS


class Gestore(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def rispondi(self, codice, corpo, tipo="application/json"):
        self.send_response(codice); self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo))); self.end_headers(); self.wfile.write(corpo)
    def do_GET(self):
        if not MS.gestisci(self, "GET", b""): self.rispondi(404, b"{}")
    def do_POST(self):
        corpo = self.rfile.read(min(int(self.headers.get("Content-Length", 0)), 1 << 20))
        if not MS.gestisci(self, "POST", corpo): self.rispondi(404, b"{}")


if __name__ == "__main__":
    MS.avvia()
    print("IDQ Monitor: server in ascolto sulla porta", os.environ.get("PORTA", "8002"), "- token in", MS._file("monitor.token"), flush=True)
    ThreadingHTTPServer(("0.0.0.0", int(os.environ.get("PORTA", "8002"))), Gestore).serve_forever()
'''

COMPOSE = '''services:
  idq-monitor:
    image: python:3.12-slim
    container_name: idq-monitor
    restart: unless-stopped
    network_mode: host          # cosi' il server legge il computer su cui gira (CPU, memoria, dischi...)
    working_dir: /app
    command: python -u idq_monitor_server.py
    environment:
      - PORTA=8002
    volumes:
      - ./monitor_server.py:/app/monitor_server.py:ro
      - ./idq_monitor_server.py:/app/idq_monitor_server.py:ro
      - ./dati:/dati            # token, PIN, scelte: qui dentro
'''


def _risorsa(nome):
    for d in (DATI_DIR, CARTELLA):
        try: return open(os.path.join(d, nome), "rb").read()
        except OSError: pass
    return None


def pacchetto_server():
    """Zip con tutto il necessario per avere il proprio server del monitor."""
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("idq-monitor-server/monitor_server.py", open(os.path.join(CARTELLA, "monitor_server.py"), "rb").read())
        z.writestr("idq-monitor-server/idq_monitor_server.py", RUNNER)
        z.writestr("idq-monitor-server/docker-compose.yml", COMPOSE)
        z.writestr("idq-monitor-server/dati/.gitkeep", "")
        g = _risorsa("guida_monitor.html")
        if g: z.writestr("idq-monitor-server/dati/guida_monitor.html", g)
        z.writestr("idq-monitor-server/LEGGIMI.txt", "IDQ Monitor - il tuo server.\n\n1) Copia questa cartella sul computer che resta sempre acceso (con Docker).\n2) Nella cartella: docker compose up -d\n3) Leggi il token: cat dati/monitor.token\n4) Segui la guida: https://IL-TUO-DOMINIO/guida-server (o la pagina 'Come avere il tuo server' dell'app).\n")
    return b.getvalue()


# ---------------------------------------------------------------- instradamento delle richieste
def _json(h, codice, obj): h.rispondi(codice, json.dumps(obj).encode())


def _base(h): return "https://" + (h.headers.get("X-Forwarded-Host") or h.headers.get("Host") or "")


def _nome_pc(v): return re.sub(r"[^A-Za-z0-9_-]", "", str(v or ""))[:24]


def gestisci(h, metodo, corpo):
    """Gestisce le richieste del monitor. Ritorna True se la richiesta e' sua (e ha gia' risposto)."""
    p, _, q = h.path.partition("?")
    if not (p.startswith(("/monitor", "/guida-server", "/prova"))): return False
    qs = urllib.parse.parse_qs(q)
    k = qs.get("k", [""])[0]

    # ---- pagine e file pubblici (nessun dato personale)
    if metodo == "GET" and p in ("/guida-server", "/guida-server/"):
        g = _risorsa("guida_server.html")
        h.rispondi(200 if g else 404, g or b"guida non installata", "text/html; charset=utf-8"); return True
    if metodo == "GET" and p == "/guida-server/idq-monitor-server.zip":
        try: h.rispondi(200, pacchetto_server(), "application/zip")
        except OSError: h.rispondi(404, b"pacchetto non disponibile")
        return True
    if metodo == "GET" and (p == "/guida-server/agente.py" or p.startswith("/guida-server/agenti/")):
        piatt = p.rsplit("/", 1)[1]
        dati = _risorsa("agente_pc.py") if p.endswith("agente.py") else (_risorsa("agenti/" + piatt + (".exe" if piatt.startswith("windows") else "")) if piatt in PIATTAFORME else None)
        h.rispondi(200 if dati else 404, dati or b"non disponibile", "application/octet-stream"); return True
    if metodo == "POST" and p == "/prova/nuova":
        try:
            ip = h.headers.get("CF-Connecting-IP") or h.client_address[0]
            cod, ris = nuova_prova(json.loads(corpo).get("dispositivo"), ip, _base(h))
            _json(h, cod, ris)
        except Exception as e: _json(h, 400, {"error": str(e)})
        return True
    if not p.startswith("/monitor"): return False

    # ---- da qui serve il token di uno spazio
    sp, errore = spazio_da_token(k)
    if sp is None:
        if errore == 410: _json(h, 410, {"error": "prova_scaduta"})
        else: h.rispondi(403, b"{}")
        return True
    pc = _nome_pc(qs.get("pc", ["server"])[0]) or "server"

    if metodo == "GET":
        if p == "/monitor/elenco": _json(h, 200, elenco(sp))
        elif p == "/monitor.json": _json(h, 200, dati_pc(sp, pc))
        elif p == "/monitor/manifest.json":
            h.rispondi(200, json.dumps({"name": "IDQ Monitor", "short_name": "IDQ Monitor", "start_url": "/monitor?k=" + k, "display": "standalone",
                                        "background_color": "#0f1720", "theme_color": "#0f1720", "icons": []}).encode(), "application/manifest+json")
        elif p == "/monitor/agente.py":
            d = _risorsa("agente_pc.py"); h.rispondi(200 if d else 404, d or b"agente non installato", "text/x-python; charset=utf-8")
        elif p.startswith("/monitor/agente/"):
            piatt = p.rsplit("/", 1)[1]
            if piatt not in PIATTAFORME: h.rispondi(404, b"piattaforma sconosciuta"); return True
            nome = "agenti/" + piatt + (".exe" if piatt.startswith("windows") else "")
            d = _risorsa(nome)
            if d is None:   # un server nuovo li scarica una volta dal server di origine e li tiene
                try:
                    r = urllib.request.Request(AGENTI_URL + "/" + piatt, headers={"User-Agent": "Mozilla IDQ-Monitor-server"})
                    d = urllib.request.urlopen(r, timeout=60).read(); os.makedirs(_file("agenti"), exist_ok=True); open(_file(nome), "wb").write(d)
                except Exception: d = None
            h.rispondi(200 if d else 404, d or b"eseguibile non disponibile", "application/octet-stream")
        elif p == "/monitor/installa":
            nome = _nome_pc(qs.get("nome", [""])[0])
            if not nome or nome == "server": h.rispondi(400, b"scegli un nome (lettere, numeri, - e _), diverso da 'server'"); return True
            win = "powershell" in (h.headers.get("User-Agent") or "").lower() or qs.get("sistema", [""])[0] == "windows"
            sc = (SCRIPT_INSTALLA_WINDOWS if win else SCRIPT_INSTALLA).replace("__NOME__", nome).replace("__BASE__", _base(h)).replace("__K__", k)
            h.rispondi(200, sc.encode(), "text/plain; charset=utf-8")
        elif p == "/monitor/pin": _json(h, 200, {"stato": stato_pin(sp)})
        elif p == "/monitor/guida":
            g = _risorsa("guida_monitor.html"); h.rispondi(200 if g else 404, g or b"guida non installata", "text/html; charset=utf-8")
        elif p == "/monitor": h.rispondi(200, PAGINA_MONITOR.replace("__K__", k).encode(), "text/html; charset=utf-8")
        else: h.rispondi(404, b"{}")
        return True

    # ---- POST
    if len(corpo) > (262144 if sp.prova else 1 << 20): _json(h, 413, {"error": "troppo grande"}); return True
    try: c = json.loads(corpo or b"{}")
    except ValueError: _json(h, 400, {"error": "json non valido"}); return True
    if p == "/monitor/push":
        nome = _nome_pc(c.get("pc"))
        if nome == "server":
            if sp.prova: _json(h, 400, {"error": "nome riservato"}); return True
            sp.attivita_server[0] = time.time(); sp.attivita_server[1] = c   # l'agente sul server manda solo le attivita' (aggiornamenti, lavori, servizi)
            _json(h, 200, {"ok": True, "comando": comando_per(sp, "server")}); return True
        if not nome: _json(h, 400, {"error": "nome"}); return True
        if sp.prova and nome not in sp.pc_inviati and len(sp.pc_inviati) >= PC_MAX_PROVA: _json(h, 400, {"error": "troppi PC nella prova"}); return True
        sp.pc_inviati[nome] = (time.time(), c)
        _json(h, 200, {"ok": True, "comando": comando_per(sp, nome)}); return True
    if p == "/monitor/comando":
        nome = _nome_pc(c.get("pc"))
        if sp.prova: _json(h, 403, {"error": "non disponibile nella prova"}); return True
        if c.get("azione") != "riavvia" or not nome or (nome != "server" and nome not in sp.pc_inviati): _json(h, 400, {"error": "comando non valido"}); return True
        v = pin_valido(sp, c.get("pin", ""))
        if v is None: _json(h, 429, {"error": "troppi tentativi, riprova tra 5 minuti"}); return True
        if not v: _json(h, 403, {"error": "pin"}); return True
        sp.comandi[nome] = (time.time(), "riavvia"); print("comando riavvia per", nome, flush=True)
        _json(h, 200, {"ok": True}); return True
    if p == "/monitor/servizi":
        nome = _nome_pc(c.get("pc")); sc = c.get("scelti")
        if not nome or (nome != "server" and nome not in sp.pc_inviati): _json(h, 400, {"error": "pc sconosciuto"}); return True
        if sc is None: sp.scelti.pop(nome, None)   # torna ai servizi predefiniti
        else:
            if not isinstance(sc, list) or len(sc) > 300 or not all(isinstance(n, str) and 0 < len(n) <= 80 for n in sc): _json(h, 400, {"error": "elenco non valido"}); return True
            sp.scelti[nome] = sc
        if not sp.prova: json.dump(sp.scelti, open(_file("servizi.json"), "w"), ensure_ascii=False)
        _json(h, 200, {"ok": True}); return True
    if p == "/monitor/pin":
        cod, ris = gestisci_pin(sp, c); _json(h, cod, ris); return True
    h.rispondi(404, b"{}"); return True
