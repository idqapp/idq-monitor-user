#!/usr/bin/env python3
"""IDQ Monitor - agente per Linux (PC, Raspberry): rileva CPU per core, carico, RAM, swap, dischi con partizioni, rete, temperature
e li invia ogni 3 secondi al server IDQ (POST /monitor/push). Solo libreria standard.
Configurazione: ~/.config/idq-monitor-agente.json  {"link": "https://…/monitor?k=TOKEN", "nome": "joker", "solo_attivita": false, "servizi": {"Ollama": {"porta": 11434, "systemd": "ollama"}, "Redis": {"porta": 6379, "docker": "chat_redis"}}}"""
import glob, json, os, re, signal, socket, subprocess, sys, time, urllib.request

LINUX = sys.platform.startswith("linux")
WINDOWS = sys.platform == "win32"
if WINDOWS:
    CFG = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "idq-monitor-agente.json")
else:
    CFG = os.path.expanduser("~/.config/idq-monitor-agente.json")


def cpu():
    out = []
    for r in open("/proc/stat"):
        if not r.startswith("cpu"): break
        v = [int(x) for x in r.split()[1:]]; out.append((sum(v), v[3] + v[4]))
    return out


def dischi_io():
    io = {}
    for r in open("/proc/diskstats"):
        f = r.split(); io[f[2]] = (int(f[5]) * 512, int(f[9]) * 512)
    return io


def rete():
    rx = tx = 0
    for r in list(open("/proc/net/dev"))[2:]:
        n, v = r.split(":"); n = n.strip(); v = v.split()
        if n == "lo" or n.startswith(("docker", "br-", "veth")): continue
        rx += int(v[0]); tx += int(v[8])
    return rx, tx


def montaggi():
    m = {}
    for r in open("/proc/mounts"):
        f = r.split()
        if f[0].startswith("/dev/") and f[0] not in m: m[f[0][5:]] = f[1].replace("\\040", " ")
    return m


def modello(nome):
    try: return open(f"/sys/block/{nome}/device/model").read().strip()
    except OSError: return ""


def partizioni(io1, io2, dt, mont):
    elenco = []
    for r in list(open("/proc/partitions"))[2:]:
        f = r.split()
        if len(f) == 4 and not f[3].startswith(("loop", "ram", "zram", "dm-")): elenco.append((f[3], int(f[2]) * 1024))
    dischi = []
    for n, t in elenco:
        madre = next((d for d in dischi if n.startswith(d["nome"]) and n != d["nome"] and n[len(d["nome"]):].lstrip("p").isdigit()), None)
        if madre:
            p = {"nome": n, "size": t, "usato": None}
            if n in mont:
                p["punto"] = mont[n]
                try:
                    st = os.statvfs(mont[n]); p["usato"] = (st.f_blocks - st.f_bavail) * st.f_frsize
                except OSError: pass
            madre["parti"].append(p)
        else:
            a, b = io2.get(n, (0, 0)), io1.get(n, (0, 0))
            dischi.append({"nome": n, "size": t, "parti": [], "modello": modello(n),
                           "lett": int((a[0] - b[0]) / dt), "scritt": int((a[1] - b[1]) / dt)})
    return dischi


def porta_aperta(p):
    try:
        with socket.create_connection(("127.0.0.1", int(p)), timeout=0.5): return True
    except OSError: return False


def _esegui(cmd):
    try: return subprocess.run(cmd, capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception: return ""


ATTESA_AVVIO = 300   # secondi: un servizio appena partito (o dopo un riavvio) puo' non rispondere ancora, non e' un errore


def _da_poco_docker(inizio):
    try:
        from datetime import datetime, timezone
        t = datetime.fromisoformat(inizio.replace("Z", "+00:00").split(".")[0] + "+00:00")
        return (datetime.now(timezone.utc) - t).total_seconds() < ATTESA_AVVIO
    except Exception: return False


def _da_poco_systemd(p):
    try:
        attivo_da = int(p.get("ActiveEnterTimestampMonotonic", 0)) / 1e6
        return float(open("/proc/uptime").read().split()[0]) - attivo_da < ATTESA_AVVIO
    except Exception: return False


def stato_servizio(cfg):
    """'attivo', 'fermo' (spento in modo normale: non usato) o 'anomalo' (arrestato in modo anomalo: errore, crash, memoria esaurita).
    cfg: una porta (numero) oppure {"porta": N, "systemd": "unita", "utente": true, "docker": "contenitore"}."""
    if not isinstance(cfg, dict): cfg = {"porta": cfg}
    porta, unita, doc = cfg.get("porta"), cfg.get("systemd"), cfg.get("docker")
    if doc:
        v = _esegui(["docker", "inspect", "-f", "{{.State.Status}}|{{.State.ExitCode}}|{{.State.OOMKilled}}|{{.State.Restarting}}|{{.State.StartedAt}}|{{if .State.Health}}{{.State.Health.Status}}{{end}}", doc]).split("|")
        if len(v) == 6:
            if v[0] == "running" and v[3] != "true" and v[5] == "unhealthy": return "anomalo"
            if v[0] == "running" and v[3] != "true": return "attivo" if (porta is None or porta_aperta(porta) or _da_poco_docker(v[4])) else "anomalo"
            if v[3] == "true" or v[2] == "true": return "anomalo"
            return "fermo" if v[1] in ("0", "", "137", "143") else "anomalo"   # 137/143: fermato con docker stop (se e' per memoria esaurita lo dice OOMKilled)
        return "fermo"
    if unita:
        base = ["systemctl"] + (["--user"] if cfg.get("utente") else [])
        p = dict(r.split("=", 1) for r in _esegui(base + ["show", unita, "-p", "ActiveState", "-p", "Result", "-p", "ActiveEnterTimestampMonotonic"]).splitlines() if "=" in r)
        if p.get("ActiveState") == "active": return "attivo" if (porta is None or porta_aperta(porta) or _da_poco_systemd(p)) else "anomalo"
        if p.get("ActiveState") == "failed" or p.get("Result", "success") not in ("success", ""): return "anomalo"
        return "fermo"
    return "attivo" if porta_aperta(porta) else "fermo"   # senza unita' ne' contenitore non si capisce il motivo: fermo


RUMORE_LINUX = re.compile(r"^(systemd-|user@|user-runtime-dir@|getty@|serial-getty@|dbus|polkit|rtkit|accounts-daemon|udisks2|upower|ModemManager|wpa_supplicant|"
                          r"avahi-daemon|irqbalance|multipathd|switcheroo|power-profiles|colord|plymouth|setvtrgb|console-setup|keyboard-setup|apparmor|lvm2|blk-availability|"
                          r"cloud-|finalrd|gnome-remote|gdm|snapd\.|packagekit|unattended-upgrades|kerneloops|apport|rsyslog|cron|networkd-dispatcher|fwupd|thermald|e2scrub|open-vm|vmtoolsd|"
                          r"ssh@|sshd-keygen|ufw|qemu-guest|lightdm|bluetooth|cups|speech-dispatcher|geoclue|low-memory-monitor|pipewire|wireplumber)")
_cache_rilevati = [0, {}]
_configurati = {}   # servizi gia' in configurazione: non si ripetono nell'elenco dei rilevati


def servizi_rilevati(docker=True):
    """Tutti i servizi che il PC sta eseguendo (non solo quelli in configurazione), con il loro stato: l'utente sceglie dall'app quali visualizzare.
    Aggiornato al massimo ogni 20 secondi."""
    if time.time() - _cache_rilevati[0] < 20: return _cache_rilevati[1]
    gia = set()
    for cfg in _configurati.values():
        if isinstance(cfg, dict):
            if cfg.get("docker"): gia.add("docker: " + cfg["docker"])
            if cfg.get("systemd"): gia.add(cfg["systemd"])
            if cfg.get("servizio"): gia.add(cfg["servizio"])
    r = {}
    if LINUX:
        unita = [r_.split()[0][:-8] for r_ in _esegui(["systemctl", "list-units", "--type=service", "--all", "--no-legend", "--plain"]).splitlines()
                 if r_.split() and r_.split()[0].endswith(".service") and r_.split()[2:3] in (["active"], ["failed"])]
        for u in unita:
            if RUMORE_LINUX.match(u) or u in gia: continue
            att = _esegui(["systemctl", "show", u + ".service", "-p", "ActiveState", "--value"])
            r[u] = "attivo" if att == "active" else ("anomalo" if att == "failed" else "fermo")
    elif WINDOWS:
        try:
            import psutil
            for sv in psutil.win_service_iter():
                try:
                    if sv.status() == "running" and sv.name() not in gia and sv.display_name() not in gia: r[sv.display_name()] = "attivo"
                except Exception: pass
        except Exception: pass
    else:   # macOS
        for riga in _esegui(["launchctl", "list"]).splitlines()[1:]:
            parti = riga.split("\t")
            if len(parti) == 3 and not parti[2].startswith(("com.apple.", "application.", "[")): r[parti[2]] = "attivo" if parti[0] != "-" else "fermo"
    if docker:
        for nome in _esegui(["docker", "ps", "-a", "--format", "{{.Names}}"]).splitlines():
            if nome and ("docker: " + nome) not in gia: r["docker: " + nome] = stato_servizio({"docker": nome})
    _cache_rilevati[0] = time.time(); _cache_rilevati[1] = r
    return r


def stato_servizi(servizi, docker_tutti=False):
    st = {n: stato_servizio(c) for n, c in (servizi or {}).items()}
    if docker_tutti:   # tutti i contenitori Docker del PC, anche quelli non elencati: cosi' si vedono i servizi di tutti i progetti
        noti = {c.get("docker") for c in (servizi or {}).values() if isinstance(c, dict)}
        for nome in _esegui(["docker", "ps", "-a", "--format", "{{.Names}}"]).splitlines():
            if nome and nome not in noti: st[nome] = stato_servizio({"docker": nome})
    return st


def allarmi_servizi(st):
    return [f"Servizio arrestato in modo anomalo: {n}" for n, v in st.items() if v == "anomalo"]


def rileva(nome, servizi=None, docker_tutti=False):
    c1, io1, r1, t0 = cpu(), dischi_io(), rete(), time.time(); time.sleep(0.5)
    c2, io2, r2 = cpu(), dischi_io(), rete(); dt = max(0.1, time.time() - t0)
    perc = [round(100 * (1 - (b[1] - a[1]) / max(1, b[0] - a[0])), 1) for a, b in zip(c1, c2)]
    mem = {}
    for r in open("/proc/meminfo"):
        k, v = r.split(":"); mem[k] = int(v.split()[0]) * 1024
    ram_t = mem["MemTotal"]; ram_u = ram_t - mem["MemAvailable"]; sw_t = mem.get("SwapTotal", 0); sw_u = sw_t - mem.get("SwapFree", 0)
    carico = [float(x) for x in open("/proc/loadavg").read().split()[:3]]
    temps = []
    for f in sorted(glob.glob("/sys/class/thermal/thermal_zone*/temp")):
        try: temps.append({"nome": open(os.path.dirname(f) + "/type").read().strip(), "c": round(int(open(f).read()) / 1000, 1)})
        except (OSError, ValueError): pass
    for f in sorted(glob.glob("/sys/class/hwmon/hwmon*/temp1_input")):
        try:
            nm = open(os.path.dirname(f) + "/name").read().strip()
            if nm not in [t["nome"] for t in temps]: temps.append({"nome": nm, "c": round(int(open(f).read()) / 1000, 1)})
        except (OSError, ValueError): pass
    temp = max((t["c"] for t in temps), default=None)
    st = stato_servizi(servizi, docker_tutti)
    dis = partizioni(io1, io2, dt, montaggi()); nuclei = len(perc) - 1
    radice = os.statvfs("/"); tot = radice.f_blocks * radice.f_frsize; us = tot - radice.f_bavail * radice.f_frsize
    allarmi = []
    if perc[0] >= 95: allarmi.append(f"Processore al {perc[0]}%")
    if carico[1] > nuclei * 1.5: allarmi.append(f"Carico alto ({carico[1]:.1f} su {nuclei} core)")
    if ram_u / ram_t >= 0.92: allarmi.append(f"Memoria quasi piena ({100*ram_u/ram_t:.0f}%)")
    if sw_t and sw_u / sw_t >= 0.8: allarmi.append(f"Swap quasi piena ({100*sw_u/sw_t:.0f}%)")
    for d in dis:
        for p in d["parti"]:
            if p["usato"] and p["size"] and p["usato"] / p["size"] >= 0.9: allarmi.append(f"Partizione {p['nome']} al {100*p['usato']/p['size']:.0f}%")
    if temp is not None and temp >= 85: allarmi.append(f"Temperatura alta ({temp} C)")
    allarmi += allarmi_servizi(st)
    return {"pc": nome, "allarmi": allarmi, "cpu": perc[0], "core": perc[1:], "nuclei": nuclei, "carico": carico,
            "ram_tot": ram_t, "ram_usata": ram_u, "swap_tot": sw_t, "swap_usata": sw_u, "disco_tot": tot, "disco_usato": us,
            "dischi": dis, "rete": {"rx": int((r2[0] - r1[0]) / dt), "tx": int((r2[1] - r1[1]) / dt)},
            "temperatura": temp, "temperature": temps, "uptime": int(float(open("/proc/uptime").read().split()[0])),
            "ora": int(time.time()), "servizi": {n: v == "attivo" for n, v in st.items()}, "servizi_stato": st, "servizi_rilevati": servizi_rilevati(), "attivita": attivita()}


AGGIORNAMENTI = {"apt": "apt", "apt-get": "apt", "dpkg": "dpkg", "unattended-upgr": "aggiornamenti automatici",
                 "snap": "snap", "flatpak": "flatpak", "do-release-upgr": "avanzamento di versione di Ubuntu"}
LAVORI = {"valhalla_build_": "costruzione mappe Valhalla", "osmium": "elaborazione mappe (osmium)", "rsync": "copia file (rsync)",
          "ffmpeg": "conversione video (ffmpeg)", "gradle": "compilazione (Gradle)"}
MANUTENZIONE = os.path.join(os.environ.get("APPDATA", ""), "idq-monitor-manutenzione.txt") if WINDOWS else os.path.expanduser("~/.config/idq-monitor-manutenzione")


def processi():
    out = []
    for p in glob.glob("/proc/[0-9]*"):
        try:
            comm = open(p + "/comm").read().strip()
            cmd = open(p + "/cmdline").read().replace("\0", " ")
            out.append((comm, cmd))
        except OSError: pass
    return out


def riavvio_programmato():
    """Epoch del prossimo riavvio automatico notturno, se e' attivo e serve (altrimenti None)."""
    try:
        cfg = _esegui(["apt-config", "dump"])
        if 'Unattended-Upgrade::Automatic-Reboot "true"' not in cfg or not os.path.exists("/var/run/reboot-required"): return None
        m = re.search(r'Automatic-Reboot-Time "(\d\d):(\d\d)"', cfg); h, mi = (int(m.group(1)), int(m.group(2))) if m else (2, 30)
        from datetime import datetime, timedelta
        t = datetime.now().replace(hour=h, minute=mi, second=0, microsecond=0)
        if t.timestamp() < time.time() - 1800: t += timedelta(days=1)
        return int(t.timestamp())
    except Exception: return None


RICHIEDONO_RIAVVIO = re.compile(r"^(linux-image|linux-modules|linux-generic|linux-hwe|linux-base|libc6|systemd|dbus|udev|nvidia-driver|intel-microcode|amd64-microcode|grub)")
_cache_pronti = [0, []]


def aggiornamenti_pronti():
    """Pacchetti da installare che richiederanno un riavvio (kernel, libc, systemd, driver...). Controllo al massimo ogni 10 minuti."""
    if time.time() - _cache_pronti[0] > 600:
        _cache_pronti[0] = time.time()
        nomi = [r.split("/")[0] for r in _esegui(["apt", "list", "--upgradable"]).splitlines() if "/" in r]
        _cache_pronti[1] = sorted(n for n in nomi if RICHIEDONO_RIAVVIO.match(n))[:8]
    return _cache_pronti[1]


def pacchetti_riavvio():
    try: return sorted(set(open("/var/run/reboot-required.pkgs").read().split()))[:8]
    except OSError: return []


def attivita():
    pr = processi(); agg = set(); lav = set()
    for comm, cmd in pr:
        v = AGGIORNAMENTI.get(comm)
        # i demoni sempre accesi (unattended-upgrade-shutdown, snapd) non sono aggiornamenti in corso
        if v and "shutdown" not in cmd and (comm != "snap" or re.search(r"\b(refresh|install|remove)\b", cmd)): agg.add(v)
        if comm == "docker" and re.search(r"\b(pull|build|compose)\b", cmd): lav.add("Docker: " + ("download immagini" if "pull" in cmd else "costruzione/avvio contenitori"))
        for k, v in LAVORI.items():
            if comm.startswith(k): lav.add(v)
    da = None
    try:
        t = open("/var/lib/update-notifier/updates-available").read()
        m = re.search(r"(\d+) (?:update|aggiornament)", t); da = int(m.group(1)) if m else 0
    except OSError: pass
    try: man = open(MANUTENZIONE).read().strip()
    except OSError: man = ""
    docker = []
    try:
        o = subprocess.run(["docker", "ps", "-a", "--format", "{{.Names}}|{{.Status}}"], capture_output=True, text=True, timeout=5).stdout
        for r in o.splitlines():
            n, _, st = r.partition("|")
            if st.startswith(("Restarting", "Exited", "Dead")) and "(0)" not in st: docker.append(f"{n}: {st}")
    except Exception: pass
    return {"aggiornamenti": sorted(agg), "da_installare": da, "riavvio": os.path.exists("/var/run/reboot-required"),
            "lavori": sorted(lav), "manutenzione": man, "docker": docker, "riavvio_programmato": riavvio_programmato(),
            "riavvio_pacchetti": pacchetti_riavvio(), "aggiornamenti_pronti": aggiornamenti_pronti()}


# ------------------------------------------------------------------ Windows e macOS (richiedono psutil, incluso negli eseguibili)
def _servizio_windows(nome):
    o = _esegui(["sc", "query", nome])
    return "RUNNING" in o, ("STOPPED" in o)


def stato_servizio_altro(cfg):
    """Su Windows e macOS: porta locale, contenitore Docker e (Windows) servizio di sistema. 'anomalo' solo se Docker lo dice."""
    if not isinstance(cfg, dict): cfg = {"porta": cfg}
    if cfg.get("docker"): return stato_servizio({"docker": cfg["docker"], "porta": cfg.get("porta")})
    if cfg.get("servizio") and WINDOWS:
        attivo, fermo = _servizio_windows(cfg["servizio"])
        if attivo: return "attivo" if (cfg.get("porta") is None or porta_aperta(cfg["porta"])) else "anomalo"
        return "fermo"
    return "attivo" if cfg.get("porta") and porta_aperta(cfg["porta"]) else "fermo"


def stato_servizi_altro(servizi, docker_tutti=False):
    st = {n: stato_servizio_altro(c) for n, c in (servizi or {}).items()}
    if docker_tutti:
        noti = {c.get("docker") for c in (servizi or {}).values() if isinstance(c, dict)}
        for nome in _esegui(["docker", "ps", "-a", "--format", "{{.Names}}"]).splitlines():
            if nome and nome not in noti: st[nome] = stato_servizio({"docker": nome})
    return st


def attivita_altro():
    try: man = open(MANUTENZIONE).read().strip()
    except OSError: man = ""
    docker = []
    o = _esegui(["docker", "ps", "-a", "--format", "{{.Names}}|{{.Status}}"])
    for r in o.splitlines():
        n, _, st = r.partition("|")
        if st.startswith(("Restarting", "Exited", "Dead")) and "(0)" not in st: docker.append(f"{n}: {st}")
    return {"aggiornamenti": [], "da_installare": None, "riavvio": False, "lavori": [], "manutenzione": man, "docker": docker,
            "riavvio_programmato": None, "riavvio_pacchetti": [], "aggiornamenti_pronti": []}


def rileva_altro(nome, servizi=None, docker_tutti=False):
    import psutil
    c1 = psutil.cpu_percent(percpu=True, interval=0.5)
    io1 = psutil.disk_io_counters(); r1 = psutil.net_io_counters(); t0 = time.time()
    time.sleep(0.5); dt = max(0.1, time.time() - t0)
    io2 = psutil.disk_io_counters(); r2 = psutil.net_io_counters()
    core = [round(x, 1) for x in psutil.cpu_percent(percpu=True, interval=None)] or [round(x, 1) for x in c1]
    cpu = round(sum(core) / max(1, len(core)), 1)
    vm = psutil.virtual_memory(); sw = psutil.swap_memory()
    try: carico = [round(x, 2) for x in psutil.getloadavg()]
    except Exception: carico = [0.0, 0.0, 0.0]
    dischi = []; tot_radice = (0, 0)
    for p in psutil.disk_partitions(all=False):
        if WINDOWS and "cdrom" in p.opts: continue
        if p.fstype in ("squashfs", "iso9660", "tmpfs", "devfs", "autofs", "overlay", "") or "loop" in p.device: continue
        if p.mountpoint.startswith("/System/Volumes/") and not p.mountpoint.endswith("/Data"): continue   # macOS: volumi tecnici
        if p.mountpoint.startswith(("/snap", "/private/var/vm")): continue
        try: u = psutil.disk_usage(p.mountpoint)
        except OSError: continue
        nomedisco = p.device.rstrip("\\") if WINDOWS else p.device.replace("/dev/", "")
        dischi.append({"nome": nomedisco, "size": u.total, "modello": p.fstype, "lett": 0, "scritt": 0,
                       "parti": [{"nome": nomedisco, "size": u.total, "usato": u.used, "punto": p.mountpoint}]})
        if not tot_radice[0] or p.mountpoint in ("/", "C:\\"): tot_radice = (u.total, u.used)
    if dischi and io1 and io2:   # traffico totale dei dischi: attribuito al primo disco
        dischi[0]["lett"] = int((io2.read_bytes - io1.read_bytes) / dt); dischi[0]["scritt"] = int((io2.write_bytes - io1.write_bytes) / dt)
    temps = []
    try:
        for n, lista in (psutil.sensors_temperatures() or {}).items():
            for e in lista: temps.append({"nome": e.label or n, "c": round(e.current, 1)})
    except Exception: pass
    temp = max((t["c"] for t in temps), default=None)
    st = stato_servizi_altro(servizi, docker_tutti)
    allarmi = []
    if cpu >= 95: allarmi.append(f"Processore al {cpu}%")
    if vm.percent >= 92: allarmi.append(f"Memoria quasi piena ({vm.percent:.0f}%)")
    if sw.total and sw.percent >= 80: allarmi.append(f"Swap quasi piena ({sw.percent:.0f}%)")
    for d in dischi:
        for p in d["parti"]:
            if p["size"] and p["usato"] / p["size"] >= 0.9: allarmi.append(f"Partizione {p['nome']} al {100*p['usato']/p['size']:.0f}%")
    if temp is not None and temp >= 85: allarmi.append(f"Temperatura alta ({temp} C)")
    allarmi += allarmi_servizi(st)
    return {"pc": nome, "allarmi": allarmi, "cpu": cpu, "core": core, "nuclei": len(core), "carico": carico,
            "ram_tot": vm.total, "ram_usata": vm.total - vm.available, "swap_tot": sw.total, "swap_usata": sw.used,
            "disco_tot": tot_radice[0], "disco_usato": tot_radice[1], "dischi": dischi,
            "rete": {"rx": int((r2.bytes_recv - r1.bytes_recv) / dt), "tx": int((r2.bytes_sent - r1.bytes_sent) / dt)},
            "temperatura": temp, "temperature": temps, "uptime": int(time.time() - psutil.boot_time()), "ora": int(time.time()),
            "servizi": {n: v == "attivo" for n, v in st.items()}, "servizi_stato": st, "servizi_rilevati": servizi_rilevati(), "attivita": attivita_altro()}


def installa_arresto(avvisa):
    """Chiede al sistema di avvisare l'agente quando il PC si spegne, si riavvia o l'utente esce: SIGTERM (macOS/Linux), eventi della console (Windows)."""
    signal.signal(signal.SIGTERM, avvisa)
    if WINDOWS:
        import ctypes
        from ctypes import wintypes
        gestore = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.DWORD)(lambda ev: (avvisa() if ev in (2, 5, 6) else None) or True)
        ctypes.windll.kernel32.SetConsoleCtrlHandler(gestore, True)
        globals()["_gestore_windows"] = gestore   # deve restare vivo


def esegui_comando(risposta):
    """Il server puo' trasmettere 'riavvia' (confermato da Paolo nell'app). Si riavvia solo se un riavvio e' davvero necessario."""
    try: cmd = json.loads(risposta).get("comando")
    except Exception: return
    if cmd == "riavvia" and LINUX and os.path.exists("/var/run/reboot-required"):
        print("riavvio richiesto dall'app", flush=True)
        subprocess.run(["sudo", "-n", "/usr/bin/systemctl", "reboot"], timeout=20)


def main():
    c = json.load(open(CFG)); link = c["link"]
    _configurati.update(c.get("servizi") or {})
    base = re.match(r"^(https?://[^/]+)", link).group(1); k = re.search(r"[?&]k=([^&\s]+)", link).group(1)
    nome = c.get("nome") or re.sub(r"[^A-Za-z0-9_-]", "", socket.gethostname())
    solo = c.get("solo_attivita", False)   # sul server i dati base li legge gia' il servizio: l'agente manda solo le attivita'

    def spegnimento(*_):
        """Il PC viene spento o riavviato in modo normale (il sistema ferma il servizio): lo comunica, cosi' non scatta l'allarme di PC spento."""
        try:
            urllib.request.urlopen(urllib.request.Request(f"{base}/monitor/push?k={k}", json.dumps({"pc": nome, "spegnimento": True}).encode(),
                                   {"Content-Type": "application/json", "User-Agent": "IDQ-Monitor-agente/1.0"}), timeout=3).read()
        except Exception: pass
        sys.exit(0)
    installa_arresto(spegnimento)
    while True:
        try:
            if solo:
                st = stato_servizi(c.get("servizi"), c.get("docker_tutti", False))
                dati = {"pc": nome, "attivita": attivita(), "servizi_stato": st, "servizi_rilevati": servizi_rilevati(), "allarmi": allarmi_servizi(st)}
            elif LINUX:
                dati = rileva(nome, c.get("servizi"), c.get("docker_tutti", False))
            else:
                dati = rileva_altro(nome, c.get("servizi"), c.get("docker_tutti", False))
            r = urllib.request.Request(f"{base}/monitor/push?k={k}", json.dumps(dati).encode(),
                                       {"Content-Type": "application/json", "User-Agent": "IDQ-Monitor-agente/1.0"})
            esegui_comando(urllib.request.urlopen(r, timeout=8).read().decode())
        except Exception as e:
            print("errore:", e, flush=True); time.sleep(5)
        time.sleep(2.5)


if __name__ == "__main__":
    if "--prova" in sys.argv:   # prova senza server: stampa i dati rilevati (usata anche per verificare gli eseguibili)
        print(json.dumps(rileva(socket.gethostname()) if LINUX else rileva_altro(socket.gethostname()), indent=1)[:1500])
    else:
        main()
