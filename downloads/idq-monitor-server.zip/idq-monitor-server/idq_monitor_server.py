#!/usr/bin/env python3
"""IDQ Monitor - avvio del server del monitor da solo (nessuna dipendenza oltre a Python 3).  Uso: python3 idq_monitor_server.py"""
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import monitor_server as MS


class Gestore(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def rispondi(self, codice, corpo, tipo="application/json"):
        self.send_response(codice); self.send_header("Content-Type", tipo)
        self.send_header("Cache-Control", "no-store"); self.send_header("Content-Length", str(len(corpo))); self.end_headers(); self.wfile.write(corpo)
    def do_GET(self):
        if not MS.gestisci(self, "GET", b""): self.rispondi(404, b"{}")
    def do_POST(self):
        corpo = self.rfile.read(min(int(self.headers.get("Content-Length", 0)), 1 << 20))
        if not MS.gestisci(self, "POST", corpo): self.rispondi(404, b"{}")


if __name__ == "__main__":
    MS.avvia()
    print("IDQ Monitor: server in ascolto sulla porta", os.environ.get("PORTA", "8002"), "- token in", MS._file("monitor.token"), flush=True)
    ThreadingHTTPServer(("0.0.0.0", int(os.environ.get("PORTA", "8002"))), Gestore).serve_forever()
