#!/bin/bash
# IDQ Monitor - collega questo Mac al monitor (avvia l'agente a ogni accesso). Doppio clic per eseguire.
cd "$(dirname "$0")"
read -r -p "Link del monitor (https://.../monitor?k=...): " LINK
read -r -p "Nome di questo Mac [$(scutil --get ComputerName 2>/dev/null | tr -cd 'A-Za-z0-9_-')]: " NOME
NOME="${NOME:-$(scutil --get ComputerName 2>/dev/null | tr -cd 'A-Za-z0-9_-')}"; NOME="$(echo "$NOME" | tr -cd 'A-Za-z0-9_-' | cut -c1-24)"
case "$LINK" in https://*monitor*k=*) ;; *) echo "Il link non sembra corretto."; exit 1;; esac
mkdir -p "$HOME/idq-monitor" "$HOME/.config" "$HOME/Library/LaunchAgents"
cp agente/IDQ-Monitor-Agente "$HOME/idq-monitor/idq-monitor-agente"; chmod +x "$HOME/idq-monitor/idq-monitor-agente"
xattr -d com.apple.quarantine "$HOME/idq-monitor/idq-monitor-agente" 2>/dev/null || true
printf '{"link": "%s", "nome": "%s"}\n' "$LINK" "$NOME" > "$HOME/.config/idq-monitor-agente.json"; chmod 600 "$HOME/.config/idq-monitor-agente.json"
PLIST="$HOME/Library/LaunchAgents/it.idq.monitor-agente.plist"
cat > "$PLIST" <<EOT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>it.idq.monitor-agente</string>
<key>ProgramArguments</key><array><string>$HOME/idq-monitor/idq-monitor-agente</string></array>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>StandardErrorPath</key><string>$HOME/idq-monitor/agente.log</string>
</dict></plist>
EOT
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
echo "Fatto: questo Mac compare in IDQ Monitor come '$NOME' entro pochi secondi."
echo "Per rimuoverlo: launchctl bootout gui/$(id -u) $PLIST && rm -rf ~/idq-monitor $PLIST"
